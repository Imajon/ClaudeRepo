const { SerialPort } = require('serialport');
const EventEmitter = require('events');

// ─── Constantes protocole RPLiDAR ────────────────────────────────────────────
const SYNC_BYTE    = 0xA5;
const SYNC_BYTE2   = 0x5A;

const CMD = {
  STOP:          0x25,
  RESET:         0x40,
  SCAN:          0x20,
  EXPRESS_SCAN:  0x82,
  GET_INFO:      0x50,
  GET_HEALTH:    0x52,
  SET_MOTOR_PWM: 0xF0,  // payload 2 bytes little-endian (valeur PWM)
};

// PWM moteur : 0 = arrêt, 1023 = max. La démo officielle SLAMTEC utilise 600.
const MOTOR_PWM_DEFAULT = 600;
const MOTOR_PWM_MAX     = 1023;

// Taille d'une réponse descripteur
const DESCRIPTOR_SIZE = 7;
// Taille d'un paquet de scan standard
const SCAN_PACKET_SIZE = 5;

// ─── États du parser ─────────────────────────────────────────────────────────
const PARSER_STATE = {
  IDLE:            'IDLE',
  WAIT_DESCRIPTOR: 'WAIT_DESCRIPTOR',
  READ_DESCRIPTOR: 'READ_DESCRIPTOR',
  READ_RESPONSE:   'READ_RESPONSE',
  READ_SCAN:       'READ_SCAN',
};

class LidarA2 extends EventEmitter {
  constructor(portPath, baudRate = 115200) {
    super();
    this.portPath = portPath;
    this.baudRate = baudRate;
    this.port = null;
    this.buffer = Buffer.alloc(0);
    this.state = PARSER_STATE.IDLE;
    this.descriptor = null;
    this.pendingCommand = null;
    this._scanning = false;
    this._scanPoints = [];
    this._lastAngle = -1;
  }

  // ─── Lister les ports série disponibles ─────────────────────────────────
  static async listPorts() {
    const ports = await SerialPort.list();
    return ports.map(p => ({
      path: p.path,
      manufacturer: p.manufacturer || '',
      serialNumber: p.serialNumber || '',
      vendorId: p.vendorId || '',
      productId: p.productId || '',
    }));
  }

  // ─── Connexion ──────────────────────────────────────────────────────────
  connect() {
    return new Promise((resolve, reject) => {
      this.port = new SerialPort({
        path: this.portPath,
        baudRate: this.baudRate,
        autoOpen: false,
      });

      this.port.open((err) => {
        if (err) return reject(new Error(`Impossible d'ouvrir ${this.portPath}: ${err.message}`));
        console.log(`[LidarA2] Connecté sur ${this.portPath}`);
        this.port.on('data', (data) => this._onData(data));
        this.port.on('error', (err) => this.emit('error', err));
        resolve();
      });
    });
  }

  // ─── Démarrer le moteur (RTS + SET_MOTOR_PWM) ───────────────────────────
  // Le A2 utilise le signal RTS pour alimenter le moteur.
  // On envoie aussi SET_MOTOR_PWM pour fixer la vitesse.
  async startMotor(pwm = MOTOR_PWM_DEFAULT) {
    // 1. Activer le signal RTS → alimente le driver moteur
    await this._setRTS(true);
    await new Promise(r => setTimeout(r, 50));

    // 2. Envoyer SET_MOTOR_PWM avec la valeur souhaitée (little-endian 2 bytes)
    const payload = [pwm & 0xFF, (pwm >> 8) & 0xFF];
    await this._sendCommand(CMD.SET_MOTOR_PWM, payload);

    console.log(`[LidarA2] Moteur démarré (PWM=${pwm})`);
    this.emit('motor', { running: true, pwm });
  }

  // ─── Arrêter le moteur ────────────────────────────────────────────────────
  async stopMotor() {
    // PWM à 0 puis couper RTS
    const payload = [0x00, 0x00];
    await this._sendCommand(CMD.SET_MOTOR_PWM, payload);
    await new Promise(r => setTimeout(r, 50));
    await this._setRTS(false);
    console.log('[LidarA2] Moteur arrêté');
    this.emit('motor', { running: false, pwm: 0 });
  }

  // ─── Contrôle du signal RTS ───────────────────────────────────────────────
  _setRTS(value) {
    return new Promise((resolve, reject) => {
      this.port.set({ rts: value }, (err) => {
        if (err) return reject(err);
        resolve();
      });
    });
  }


  _sendCommand(cmd, payload = null) {
    let packet;
    if (payload && payload.length > 0) {
      const size = payload.length;
      let checksum = 0;
      checksum ^= SYNC_BYTE;
      checksum ^= cmd;
      checksum ^= size;
      for (const b of payload) checksum ^= b;

      packet = Buffer.from([SYNC_BYTE, cmd, size, ...payload, checksum]);
    } else {
      packet = Buffer.from([SYNC_BYTE, cmd]);
    }

    return new Promise((resolve, reject) => {
      this.port.write(packet, (err) => {
        if (err) return reject(err);
        resolve();
      });
    });
  }

  // ─── GET_INFO ────────────────────────────────────────────────────────────
  async getInfo() {
    this.pendingCommand = CMD.GET_INFO;
    this.state = PARSER_STATE.WAIT_DESCRIPTOR;
    this.buffer = Buffer.alloc(0);
    await this._sendCommand(CMD.GET_INFO);
    // La réponse sera traitée dans _onData → emit('info', ...)
  }

  // ─── GET_HEALTH ──────────────────────────────────────────────────────────
  async getHealth() {
    this.pendingCommand = CMD.GET_HEALTH;
    this.state = PARSER_STATE.WAIT_DESCRIPTOR;
    this.buffer = Buffer.alloc(0);
    await this._sendCommand(CMD.GET_HEALTH);
  }

  // ─── Démarrer le scan ────────────────────────────────────────────────────
  async startScan() {
    this.pendingCommand = CMD.SCAN;
    this.state = PARSER_STATE.WAIT_DESCRIPTOR;
    this.buffer = Buffer.alloc(0);
    this._scanning = true;
    this._scanPoints = [];
    this._lastAngle = -1;
    await this._sendCommand(CMD.SCAN);
    console.log('[LidarA2] Scan démarré');
  }

  // ─── Arrêter scan + moteur + fermer port ─────────────────────────────────
  async stop() {
    this._scanning = false;
    this.state = PARSER_STATE.IDLE;
    if (this.port && this.port.isOpen) {
      await this._sendCommand(CMD.STOP);       // arrêter le scan
      await new Promise(r => setTimeout(r, 100));
      await this.stopMotor();                  // couper le moteur proprement
      await new Promise(r => setTimeout(r, 100));
      return new Promise((resolve) => {
        this.port.close(() => {
          console.log('[LidarA2] Port fermé');
          resolve();
        });
      });
    }
  }

  // ─── Réception des données série ─────────────────────────────────────────
  _onData(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    this._process();
  }

  _process() {
    while (this.buffer.length > 0) {
      switch (this.state) {

        case PARSER_STATE.IDLE:
          // Chercher le sync byte de début
          const idx = this.buffer.indexOf(SYNC_BYTE);
          if (idx === -1) {
            this.buffer = Buffer.alloc(0);
            return;
          }
          this.buffer = this.buffer.slice(idx);
          this.state = PARSER_STATE.WAIT_DESCRIPTOR;
          break;

        case PARSER_STATE.WAIT_DESCRIPTOR:
          if (this.buffer.length < DESCRIPTOR_SIZE) return; // attendre plus de data
          this.state = PARSER_STATE.READ_DESCRIPTOR;
          break;

        case PARSER_STATE.READ_DESCRIPTOR:
          if (this.buffer.length < DESCRIPTOR_SIZE) return;

          // Vérifier les deux sync bytes
          if (this.buffer[0] !== SYNC_BYTE || this.buffer[1] !== SYNC_BYTE2) {
            // Pas un vrai descripteur, avancer d'un byte
            this.buffer = this.buffer.slice(1);
            this.state = PARSER_STATE.WAIT_DESCRIPTOR;
            break;
          }

          // Lire le descripteur
          // Bytes: [0xA5][0x5A][size32 (4 bytes little-endian)][send_mode][data_type]
          const size32    = this.buffer.readUInt32LE(2); // 30 bits = taille réponse, 2 bits = mode
          const sendMode  = (size32 >> 30) & 0x03;       // 0=single, 1=multi
          const dataLen   = size32 & 0x3FFFFFFF;
          const dataType  = this.buffer[6];

          this.descriptor = { sendMode, dataLen, dataType };
          this.buffer = this.buffer.slice(DESCRIPTOR_SIZE);

          console.log(`[LidarA2] Descripteur: type=0x${dataType.toString(16)}, len=${dataLen}, mode=${sendMode}`);

          // Décider quoi faire selon le type de réponse
          if (sendMode === 0) {
            // Single response (GET_INFO, GET_HEALTH)
            this.state = PARSER_STATE.READ_RESPONSE;
          } else {
            // Multi response (SCAN)
            this.state = PARSER_STATE.READ_SCAN;
          }
          break;

        case PARSER_STATE.READ_RESPONSE:
          if (!this.descriptor) { this.state = PARSER_STATE.IDLE; break; }
          if (this.buffer.length < this.descriptor.dataLen) return;

          const respData = this.buffer.slice(0, this.descriptor.dataLen);
          this.buffer = this.buffer.slice(this.descriptor.dataLen);

          this._handleResponse(this.descriptor.dataType, respData);

          // Après une single response, s'il y a un scan en attente, aller en mode scan
          if (this._scanning) {
            this.state = PARSER_STATE.WAIT_DESCRIPTOR;
          } else {
            this.state = PARSER_STATE.IDLE;
          }
          break;

        case PARSER_STATE.READ_SCAN:
          // Paquets de 5 bytes en continu
          if (this.buffer.length < SCAN_PACKET_SIZE) return;

          const pkt = this.buffer.slice(0, SCAN_PACKET_SIZE);
          this.buffer = this.buffer.slice(SCAN_PACKET_SIZE);

          this._parseScanPacket(pkt);
          break;

        default:
          this.state = PARSER_STATE.IDLE;
          break;
      }
    }
  }

  // ─── Parser une réponse single (GET_INFO, GET_HEALTH) ────────────────────
  _handleResponse(dataType, data) {
    switch (dataType) {
      case 0x04: // GET_INFO response
        const info = {
          model:          data[0],
          firmwareMinor:  data[1],
          firmwareMajor:  data[2],
          hardware:       data[3],
          serialNumber:   data.slice(4, 20).toString('hex').toUpperCase(),
        };
        console.log('[LidarA2] Info:', info);
        this.emit('info', info);
        break;

      case 0x06: // GET_HEALTH response
        const statusCode = data[0];
        const statusMap = { 0: 'Good', 1: 'Warning', 2: 'Error' };
        const health = {
          status:    statusMap[statusCode] || 'Unknown',
          errorCode: data.readUInt16LE(1),
        };
        console.log('[LidarA2] Health:', health);
        this.emit('health', health);
        break;

      default:
        console.log(`[LidarA2] Réponse inconnue type=0x${dataType.toString(16)}`);
    }
  }

  // ─── Parser un paquet de scan (5 bytes) ──────────────────────────────────
  _parseScanPacket(pkt) {
    // Byte 0: [start_flag (bit7)] [inverted_start_flag (bit6)] [quality (bits5-0)]
    // Byte 1: [angle_lsb (bits7-1)] [check_bit (bit0)]
    // Byte 2: angle_msb
    // Bytes 3-4: distance (little-endian, unité = 0.25 mm)

    const startFlag         = (pkt[0] >> 7) & 0x01;
    const invertedStartFlag = (pkt[0] >> 6) & 0x01;
    const quality           = pkt[0] & 0x3F;
    const checkBit          = pkt[1] & 0x01;
    const angleRaw          = ((pkt[1] >> 1) | (pkt[2] << 7));
    const distanceRaw       = pkt.readUInt16LE(3);

    // Validation de base
    if (startFlag === invertedStartFlag) return; // paquet invalide
    if (checkBit !== 1) return;                  // check bit doit être 1

    const angle    = angleRaw / 64.0;            // degrés
    const distance = distanceRaw / 4.0;          // mm

    const point = {
      angle,
      distance,
      quality,
      x: distance * Math.cos((angle * Math.PI) / 180),
      y: distance * Math.sin((angle * Math.PI) / 180),
    };

    // Détecter le début d'un nouveau tour (angle repasse près de 0)
    if (startFlag === 1 && this._lastAngle > 180) {
      // Nouveau tour : émettre les points du tour précédent
      if (this._scanPoints.length > 0) {
        this.emit('scan', [...this._scanPoints]);
      }
      this._scanPoints = [];
    }

    if (distance > 0 && quality > 0) {
      this._scanPoints.push(point);
    }

    this._lastAngle = angle;
  }
}

module.exports = { LidarA2 };
