const { SerialPort } = require('serialport');
const EventEmitter = require('events');

const SYNC_BYTE    = 0xA5;
const SYNC_BYTE2   = 0x5A;

const CMD = {
  STOP:          0x25,
  RESET:         0x40,
  SCAN:          0x20,
  GET_INFO:      0x50,
  GET_HEALTH:    0x52,
  SET_MOTOR_PWM: 0xF0,
};

const MOTOR_PWM_DEFAULT = 600;
const DESCRIPTOR_SIZE   = 7;
const SCAN_PACKET_SIZE  = 5;

const PARSER_STATE = {
  IDLE:            'IDLE',
  WAIT_DESCRIPTOR: 'WAIT_DESCRIPTOR',
  READ_DESCRIPTOR: 'READ_DESCRIPTOR',
  READ_RESPONSE:   'READ_RESPONSE',
  READ_SCAN:       'READ_SCAN',
};

class LidarA2 extends EventEmitter {
  constructor(portPath, baudRate = 115200) {
    super();
    this.portPath  = portPath;
    this.baudRate  = baudRate;
    this._motorPwm = 0;
    this.port = null;
    this.buffer = Buffer.alloc(0);
    this.state = PARSER_STATE.IDLE;
    this.descriptor = null;
    this.pendingCommand = null;
    this._scanning = false;
    this._scanPoints = [];
    this._lastAngle = -1;
  }

  static async listPorts() {
    const ports = await SerialPort.list();
    return ports.map(p => ({
      path: p.path,
      manufacturer: p.manufacturer || '',
      serialNumber: p.serialNumber || '',
      vendorId: p.vendorId || '',
      productId: p.productId || '',
    }));
  }

  // ─── Connexion ──────────────────────────────────────────────────────────
  connect() {
    return new Promise((resolve, reject) => {
      this.port = new SerialPort({
        path: this.portPath,
        baudRate: this.baudRate,
        autoOpen: false,
      });

      this.port.open((err) => {
        if (err) return reject(new Error(`Impossible d'ouvrir ${this.portPath}: ${err.message}`));
        console.log(`[LidarA2] Port ouvert sur ${this.portPath} @ ${this.baudRate}`);
        this._attachDataListener();
        resolve();
      });
    });
  }

  _attachDataListener() {
    this.port.removeAllListeners('data');
    this.port.removeAllListeners('error');
    this.port.on('data',  (data) => this._onData(data));
    this.port.on('error', (err)  => this.emit('error', err));
    console.log('[LidarA2] Listener data attaché');
  }

  // ─── GET_INFO — envoie la commande et attend la réponse ─────────────────
  getInfo() {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('GET_INFO timeout (3s) — pas de réponse du capteur'));
      }, 3000);

      this.once('info', (info) => {
        clearTimeout(timeout);
        resolve(info);
      });

      // Préparer le parser AVANT d'envoyer la commande
      this.pendingCommand = CMD.GET_INFO;
      this.state = PARSER_STATE.WAIT_DESCRIPTOR;
      // Ne PAS vider le buffer ici — des bytes peuvent déjà être en route

      this._sendCommand(CMD.GET_INFO).catch(err => {
        clearTimeout(timeout);
        reject(err);
      });
    });
  }

  // ─── GET_HEALTH — envoie la commande et attend la réponse ───────────────
  getHealth() {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('GET_HEALTH timeout (3s)'));
      }, 3000);

      this.once('health', (health) => {
        clearTimeout(timeout);
        resolve(health);
      });

      this.pendingCommand = CMD.GET_HEALTH;
      this.state = PARSER_STATE.WAIT_DESCRIPTOR;

      this._sendCommand(CMD.GET_HEALTH).catch(err => {
        clearTimeout(timeout);
        reject(err);
      });
    });
  }

  // ─── Démarrer le moteur ──────────────────────────────────────────────────
  async startMotor(pwm = MOTOR_PWM_DEFAULT) {
    this._motorPwm = pwm;
    console.log(`[LidarA2] startMotor — fermeture/réouverture du port`);

    this._scanning = false;
    this.state = PARSER_STATE.IDLE;
    this.buffer = Buffer.alloc(0);

    await new Promise(res => this.port.close(res));
    await new Promise(r => setTimeout(r, 200));

    await new Promise((res, rej) => {
      this.port.open(err => err ? rej(err) : res());
    });
    console.log('[LidarA2] Port rouvert — RTS=true par défaut driver');

    // Réattacher le listener data après réouverture
    this._attachDataListener();
    await new Promise(r => setTimeout(r, 300));

    const lo = pwm & 0xFF, hi = (pwm >> 8) & 0xFF;
    let cs = 0; cs ^= 0xA5; cs ^= 0xF0; cs ^= 0x02; cs ^= lo; cs ^= hi;
    const pkt = Buffer.from([0xA5, 0xF0, 0x02, lo, hi, cs]);
    await new Promise(res => this.port.write(pkt, (err) => {
      if (err) console.warn('[LidarA2] SET_MOTOR_PWM err:', err.message);
      else     console.log(`[LidarA2] SET_MOTOR_PWM(${pwm}) envoyé`);
      res();
    }));

    await new Promise(r => setTimeout(r, 1000));

    console.log(`[LidarA2] Moteur démarré (PWM=${pwm})`);
    this.emit('motor', { running: true, pwm, baudRate: this.baudRate });
  }

  async stopMotor() {
    try {
      const payload = [0x00, 0x00];
      await this._sendCommand(CMD.SET_MOTOR_PWM, payload);
    } catch (_) {}
    await new Promise(r => setTimeout(r, 100));
    this._motorPwm = 0;
    console.log('[LidarA2] Moteur arrêté');
    this.emit('motor', { running: false, pwm: 0 });
  }

  _sendCommand(cmd, payload = null) {
    let packet;
    if (payload && payload.length > 0) {
      const size = payload.length;
      let checksum = 0;
      checksum ^= SYNC_BYTE;
      checksum ^= cmd;
      checksum ^= size;
      for (const b of payload) checksum ^= b;
      packet = Buffer.from([SYNC_BYTE, cmd, size, ...payload, checksum]);
    } else {
      packet = Buffer.from([SYNC_BYTE, cmd]);
    }

    return new Promise((resolve, reject) => {
      if (!this.port || !this.port.isOpen) {
        return reject(new Error('Port non ouvert'));
      }
      this.port.write(packet, (err) => {
        if (err) return reject(err);
        resolve();
      });
    });
  }

  async startScan() {
    this.pendingCommand = CMD.SCAN;
    this.state = PARSER_STATE.WAIT_DESCRIPTOR;
    this.buffer = Buffer.alloc(0);
    this._scanning = true;
    this._scanPoints = [];
    this._lastAngle = -1;
    await this._sendCommand(CMD.SCAN);
    console.log('[LidarA2] Scan démarré');
  }

  async stop() {
    this._scanning = false;
    this.state = PARSER_STATE.IDLE;
    if (this.port && this.port.isOpen) {
      try { await this._sendCommand(CMD.STOP); } catch (_) {}
      await new Promise(r => setTimeout(r, 100));
      await this.stopMotor();
      await new Promise(r => setTimeout(r, 100));
      return new Promise((resolve) => {
        this.port.close(() => {
          console.log('[LidarA2] Port fermé');
          resolve();
        });
      });
    }
  }

  _onData(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    this._process();
  }

  _process() {
    while (this.buffer.length > 0) {
      switch (this.state) {

        case PARSER_STATE.IDLE: {
          const idx = this.buffer.indexOf(SYNC_BYTE);
          if (idx === -1) { this.buffer = Buffer.alloc(0); return; }
          this.buffer = this.buffer.slice(idx);
          this.state = PARSER_STATE.WAIT_DESCRIPTOR;
          break;
        }

        case PARSER_STATE.WAIT_DESCRIPTOR:
          if (this.buffer.length < DESCRIPTOR_SIZE) return;
          this.state = PARSER_STATE.READ_DESCRIPTOR;
          break;

        case PARSER_STATE.READ_DESCRIPTOR: {
          if (this.buffer.length < DESCRIPTOR_SIZE) return;

          if (this.buffer[0] !== SYNC_BYTE || this.buffer[1] !== SYNC_BYTE2) {
            this.buffer = this.buffer.slice(1);
            this.state = PARSER_STATE.WAIT_DESCRIPTOR;
            break;
          }

          const size32   = this.buffer.readUInt32LE(2);
          const sendMode = (size32 >> 30) & 0x03;
          const dataLen  = size32 & 0x3FFFFFFF;
          const dataType = this.buffer[6];

          this.descriptor = { sendMode, dataLen, dataType };
          this.buffer = this.buffer.slice(DESCRIPTOR_SIZE);

          console.log(`[LidarA2] Descripteur: type=0x${dataType.toString(16)}, len=${dataLen}, mode=${sendMode}`);

          this.state = (sendMode === 0)
            ? PARSER_STATE.READ_RESPONSE
            : PARSER_STATE.READ_SCAN;
          break;
        }

        case PARSER_STATE.READ_RESPONSE: {
          if (!this.descriptor) { this.state = PARSER_STATE.IDLE; break; }
          if (this.buffer.length < this.descriptor.dataLen) return;

          const respData = this.buffer.slice(0, this.descriptor.dataLen);
          this.buffer = this.buffer.slice(this.descriptor.dataLen);

          this._handleResponse(this.descriptor.dataType, respData);

          this.state = this._scanning
            ? PARSER_STATE.WAIT_DESCRIPTOR
            : PARSER_STATE.IDLE;
          break;
        }

        case PARSER_STATE.READ_SCAN: {
          if (this.buffer.length < SCAN_PACKET_SIZE) return;

          const pkt = this.buffer.slice(0, SCAN_PACKET_SIZE);
          this.buffer = this.buffer.slice(SCAN_PACKET_SIZE);

          this._parseScanPacket(pkt);
          break;
        }

        default:
          this.state = PARSER_STATE.IDLE;
          break;
      }
    }
  }

  _handleResponse(dataType, data) {
    switch (dataType) {
      case 0x04: {
        const info = {
          model:         data[0],
          firmwareMinor: data[1],
          firmwareMajor: data[2],
          hardware:      data[3],
          serialNumber:  data.slice(4, 20).toString('hex').toUpperCase(),
        };
        console.log('[LidarA2] Info:', info);
        this.emit('info', info);
        break;
      }
      case 0x06: {
        const statusCode = data[0];
        const statusMap  = { 0: 'Good', 1: 'Warning', 2: 'Error' };
        const health = {
          status:    statusMap[statusCode] || 'Unknown',
          errorCode: data.readUInt16LE(1),
        };
        console.log('[LidarA2] Health:', health);
        this.emit('health', health);
        break;
      }
      default:
        console.log(`[LidarA2] Réponse inconnue type=0x${dataType.toString(16)}`);
    }
  }

  _parseScanPacket(pkt) {
    const startFlag         = (pkt[0] >> 7) & 0x01;
    const invertedStartFlag = (pkt[0] >> 6) & 0x01;
    const quality           = pkt[0] & 0x3F;
    const checkBit          = pkt[1] & 0x01;
    const angleRaw          = ((pkt[1] >> 1) | (pkt[2] << 7));
    const distanceRaw       = pkt.readUInt16LE(3);

    if (startFlag === invertedStartFlag) return;
    if (checkBit !== 1) return;

    const angle    = angleRaw / 64.0;
    const distance = distanceRaw / 4.0;

    const point = {
      angle,
      distance,
      quality,
      x: distance * Math.cos((angle * Math.PI) / 180),
      y: distance * Math.sin((angle * Math.PI) / 180),
    };

    if (startFlag === 1 && this._lastAngle > 180) {
      if (this._scanPoints.length > 0) {
        this.emit('scan', [...this._scanPoints]);
      }
      this._scanPoints = [];
    }

    if (distance > 0 && quality > 0) {
      this._scanPoints.push(point);
    }

    this._lastAngle = angle;
  }
}

module.exports = { LidarA2 };
