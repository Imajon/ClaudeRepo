const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { LidarA2 } = require('./lidar');

let mainWindow;
let vizWindow;
let lidar;

// ─── Broadcast vers toutes les fenêtres ─────────────────────────────────────
function broadcast(channel, data) {
  [mainWindow, vizWindow].forEach(win => {
    if (win && !win.isDestroyed()) win.webContents.send(channel, data);
  });
}

function createWindows() {
  mainWindow = new BrowserWindow({
    width: 760, height: 740,
    backgroundColor: '#080810',
    title: 'RPLiDAR A2 — Connexion',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  mainWindow.loadFile(path.join(__dirname, 'renderer/index.html'));
  mainWindow.on('closed', () => { mainWindow = null; });

  vizWindow = new BrowserWindow({
    width: 1280, height: 900,
    backgroundColor: '#000508',
    title: 'RPLiDAR A2 — Visualiseur',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  vizWindow.loadFile(path.join(__dirname, 'renderer/visualizer.html'));
  vizWindow.on('closed', () => { vizWindow = null; });
}

app.whenReady().then(createWindows);
app.on('window-all-closed', () => {
  if (lidar) lidar.stop();
  if (process.platform !== 'darwin') app.quit();
});

// ─── IPC : lister les ports ──────────────────────────────────────────────────
ipcMain.handle('lidar:list-ports', async () => LidarA2.listPorts());

// ─── IPC : connexion (sans démarrer le moteur ni le scan) ───────────────────
ipcMain.handle('lidar:connect', async (_event, { portPath, baudRate }) => {
  try {
    if (lidar) { await lidar.stop(); lidar = null; }

    lidar = new LidarA2(portPath, baudRate || 115200);
    lidar.on('scan',  (pts) => broadcast('lidar:scan', pts));
    lidar.on('info',  (i)   => broadcast('lidar:info', i));
    lidar.on('motor', (m)   => broadcast('lidar:motor', m));
    lidar.on('error', (err) => broadcast('lidar:error', err.message));

    await lidar.connect();
    await lidar.getInfo();
    await lidar.getHealth();

    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// ─── IPC : démarrer le moteur ────────────────────────────────────────────────
ipcMain.handle('lidar:start-motor', async (_event, pwm) => {
  try {
    if (!lidar) return { success: false, error: 'Non connecté' };
    const targetPwm = pwm || 600;
    console.log(`[main] start-motor pwm=${targetPwm} port.isOpen=${lidar.port?.isOpen}`);

    // ── Appel direct sur le port, identique au script de diagnostic ──────────
    const port = lidar.port;

    // 1. RTS = true
    await new Promise((res) => port.set({ rts: true }, (err) => {
      if (err) console.warn('[main] RTS warning:', err.message);
      else     console.log('[main] RTS = true OK');
      res();
    }));
    await new Promise(r => setTimeout(r, 300));

    // 2. SET_MOTOR_PWM
    const lo = targetPwm & 0xFF, hi = (targetPwm >> 8) & 0xFF;
    let cs = 0; cs ^= 0xA5; cs ^= 0xF0; cs ^= 0x02; cs ^= lo; cs ^= hi;
    const pkt = Buffer.from([0xA5, 0xF0, 0x02, lo, hi, cs]);
    await new Promise((res) => port.write(pkt, (err) => {
      if (err) console.warn('[main] SET_MOTOR_PWM warning:', err.message);
      else     console.log(`[main] SET_MOTOR_PWM(${targetPwm}) envoyé`);
      res();
    }));

    // 3. Attente montée en vitesse
    await new Promise(r => setTimeout(r, 1000));

    console.log('[main] Moteur démarré — émission event motor');
    broadcast('lidar:motor', { running: true, pwm: targetPwm });
    lidar._motorPwm = targetPwm;
    return { success: true };
  } catch (err) {
    console.error('[main] start-motor erreur:', err);
    return { success: false, error: err.message };
  }
});

// ─── IPC : démarrer le scan ──────────────────────────────────────────────────
ipcMain.handle('lidar:start-scan', async () => {
  try {
    if (!lidar) return { success: false, error: 'Non connecté' };
    await lidar.startScan();
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// ─── IPC : arrêter le scan (sans couper le moteur) ──────────────────────────
ipcMain.handle('lidar:stop-scan', async () => {
  try {
    if (!lidar) return { success: false, error: 'Non connecté' };
    lidar._scanning = false;
    await lidar._sendCommand(0x25); // CMD STOP
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// ─── IPC : déconnecter tout ──────────────────────────────────────────────────
ipcMain.handle('lidar:disconnect', async () => {
  try {
    if (lidar) { await lidar.stop(); lidar = null; }
    broadcast('lidar:motor', { running: false, pwm: 0 });
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
});

// ─── IPC : ouvrir visualiseur ────────────────────────────────────────────────
ipcMain.handle('lidar:open-viz', async () => {
  if (!vizWindow || vizWindow.isDestroyed()) {
    vizWindow = new BrowserWindow({
      width: 1280, height: 900,
      backgroundColor: '#000508',
      title: 'RPLiDAR A2 — Visualiseur',
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
        contextIsolation: true,
        nodeIntegration: false,
      },
    });
    vizWindow.loadFile(path.join(__dirname, 'renderer/visualizer.html'));
    vizWindow.on('closed', () => { vizWindow = null; });
  } else {
    vizWindow.focus();
  }
  return { success: true };
});
